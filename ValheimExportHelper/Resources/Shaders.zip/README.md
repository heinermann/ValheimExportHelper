## HiddenBlitCopyHDRTonemap
**Source**: https://github.com/repalash/Open-Shaders/blob/master/Engines/Unity/Builtin/DefaultResourcesExtra/Internal-BlitCopyHDRTonemap.shader
**License**: MIT
**Copyright**: Unity Technologies

## HiddenDofDepthOfFieldHdr
**Source**: https://github.com/microsoft/Imagine_fudge-roll/blob/master/Fudge%20Roll/assets/standard%20assets/effects/imageeffects/shaders/_DepthOfField/DepthOfFieldScatter.shader
**License**: MIT
**Copyright**: Microsoft Corporation

## HiddenDofDX11Dof
**Source**: https://github.com/microsoft/Imagine_fudge-roll/blob/master/Fudge%20Roll/assets/standard%20assets/effects/imageeffects/shaders/_DepthOfField/DepthOfFieldDX11.shader
**License**: MIT
**Copyright**: Microsoft Corporation

## HiddenInternal-Loading
**Source**: https://github.com/repalash/Open-Shaders/blob/master/Engines/Unity/Builtin/DefaultResources/Internal-Loading.shader
**License**: MIT
**Copyright**: Unity Technologies

## HiddenInternal-UIRDefaultWorld
**Source**: https://github.com/repalash/Open-Shaders/blob/master/Engines/Unity/Builtin/DefaultResourcesExtra/UIElements/Internal-UIRDefaultWorld.shader
**License**: MIT
**Copyright**: Unity Technologies

## HiddenSimpleClear
**Source**: https://github.com/microsoft/Imagine_fudge-roll/blob/master/Fudge%20Roll/assets/standard%20assets/effects/imageeffects/shaders/SimpleClear.shader
**License**: MIT
**Copyright**: Microsoft Corporation

## HiddenSunShaftsComposite
**Source**: https://github.com/microsoft/Imagine_fudge-roll/blob/master/Fudge%20Roll/assets/standard%20assets/effects/imageeffects/shaders/SunShaftsComposite.shader
**License**: MIT
**Copyright**: Microsoft Corporation

## ToonDeferredShading2017
**Source**: https://gist.github.com/xDavidLeon/690fffea93dde2d3f47c19ea87a19b02#file-toondeferredshading2017-shader
**License**: MIT
**Copyright**: Unity Technologies, David Leon
